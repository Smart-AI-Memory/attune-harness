"""The host that turns an adapter's state into one rendered, one-shot decision.

Carried from Attune AI (branch ``codex/shared-memory-adoption`` at
``b89f7953f``): ``attune/elicitation/command_workspace.py``, step 3.1 of the
spec authority's Task 3 (D14). Adapters own command state and its meaning.
The host owns adapter registration, workspace identity, revision and nonce
issuance, canonical storage, structural action validation, and at-most-once
publication of a transition. HTML and Markdown are disposable projections of
the same ``WorkspaceView``.

Three things differ from the original:

- **Events, not telemetry.** The original logged a render and an accept
  through ``attune_forms.form_events`` into Attune AI's home directory. Here
  the host takes an optional ``record_event`` callable and hands it the same
  two events; ``jsonl_event_writer`` appends them as JSON lines to a file the
  caller names, which the bridge will place beside the task's
  ``decision.json``. An event never carries the action nonce. A sink that
  fails is logged and counted in ``dropped_events``; it never blocks a
  decision.
- **Terminal workspaces are evicted.** The original kept every record and
  every ``asyncio.Lock`` for the life of the process. Here a workspace that
  reaches a terminal state is removed from both, and its id is kept in a
  bounded set so a replay is still refused with the original message.
- **The forms package loads on first use**, through ``features.require_feature``
  at the pinned version, as every other optional package in Harness does, so
  importing this module needs nothing installed.

The lock is what it always was: a guard against two coroutines in one process.
Refusal of a stale or replayed decision across processes is the task store's
job (``work_contract.bind_work_acceptance``), which D14 names as the authority.

Copyright 2026 Smart AI Memory, LLC
Licensed under the Apache License, Version 2.0
"""

from __future__ import annotations

import asyncio
import contextlib
import copy
import errno
import functools
import hmac
import json
import logging
import os
import re
import secrets
import time
import uuid
from collections import deque
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Protocol, runtime_checkable

from .features import require_feature
from .review_contract import FORMS_VERSION

logger = logging.getLogger(__name__)

_ADAPTER_ID_RE = re.compile(r"^[a-z][a-z0-9_-]{0,63}$")
_HASH_RE = re.compile(r"^[0-9a-f]{64}$")
CONSUMED_IDS_KEPT = 1024
EVENT_FILE_LIMIT = 1024 * 1024


@functools.lru_cache(maxsize=1)
def _forms():
    """The pinned forms package, loaded on first use and then kept.

    A failed load is not cached, so a missing extra is reported on every
    call until it is installed.
    """
    return require_feature("attune-forms", "attune_forms", FORMS_VERSION, "review")


class CommandWorkspaceError(ValueError):
    """A host, adapter, workspace, or action failed closed."""

    def __init__(self, problems: list[str]) -> None:
        self.problems = problems
        super().__init__("; ".join(problems))


@dataclass(frozen=True)
class CommandWorkspaceProjection:
    """One adapter-issued view and its normalized authority digest."""

    view: object
    contract_hash: str = ""

    def __post_init__(self) -> None:
        if not isinstance(self.view, _forms().WorkspaceView):
            raise TypeError("command workspace projection requires a WorkspaceView")
        if not isinstance(self.contract_hash, str):
            raise TypeError("command workspace contract hash must be a string")
        needs_binding = bool(self.view.actions) and self.view.form is None
        if needs_binding and not _HASH_RE.fullmatch(self.contract_hash):
            raise ValueError(
                "action-bearing workspace projection requires a lowercase SHA-256 digest"
            )
        if self.contract_hash and not _HASH_RE.fullmatch(self.contract_hash):
            raise ValueError("command workspace contract hash must be a SHA-256 digest")


@dataclass(frozen=True)
class CommandWorkspaceTransition:
    """Adapter-owned successor state plus portable result evidence."""

    state: object
    terminal: bool = False
    result: Mapping[str, object] = field(default_factory=dict)
    authority_changed: bool = True

    def __post_init__(self) -> None:
        if not isinstance(self.terminal, bool):
            raise TypeError("command workspace terminal flag must be a boolean")
        if not isinstance(self.result, Mapping):
            raise TypeError("command workspace transition result must be a mapping")
        if not isinstance(self.authority_changed, bool):
            raise TypeError("command workspace authority_changed must be a boolean")
        object.__setattr__(self, "result", dict(self.result))


@runtime_checkable
class CommandWorkspaceAdapter(Protocol):
    """Small command-owned seam; shared code never inspects domain state."""

    adapter_id: str
    schema_version: int

    def create(
        self,
        intake: Mapping[str, object],
        *,
        prior_state: object | None = None,
    ) -> object:
        """Create state from intake, optionally replacing adapter-approved state."""
        ...

    def project(self, state: object) -> CommandWorkspaceProjection:
        """Return the exact current view and normalized authority digest."""
        ...

    def apply(self, state: object, action: object) -> CommandWorkspaceTransition:
        """Apply one structurally validated action to canonical state."""
        ...


@runtime_checkable
class CommandWorkspacePublisher(Protocol):
    """Optional adapter capability for server-originated progress/events."""

    def publish(self, state: object, event: Mapping[str, object]) -> CommandWorkspaceTransition:
        """Apply one trusted moderator/executor event."""
        ...


@dataclass(frozen=True)
class CommandWorkspaceRecord:
    """Server-owned canonical envelope for one command interaction."""

    workspace_id: str
    adapter_id: str
    adapter_version: int
    revision: int
    state: object
    view: object
    contract_hash: str
    action_nonce: str
    terminal: bool = False
    event_sequence: int = 0

    @property
    def binding(self):
        """Return the exact one-time authority issued for this record."""
        if not self.action_nonce:
            raise CommandWorkspaceError(["command workspace is not awaiting a bound action"])
        return _forms().WorkspaceActionBinding(
            workspace_id=self.workspace_id,
            revision=self.revision,
            action_nonce=self.action_nonce,
            contract_hash=self.contract_hash,
        )


@dataclass(frozen=True)
class CommandWorkspaceRender:
    """Disposable widget and Markdown projections for one record."""

    record: CommandWorkspaceRecord
    html: str
    markdown: str

    def to_dict(self) -> dict[str, object]:
        """Return the command-neutral render result."""
        return {
            "workspace_id": self.record.workspace_id,
            "adapter_id": self.record.adapter_id,
            "adapter_version": self.record.adapter_version,
            "revision": self.record.revision,
            "view": self.record.view.id.value,
            "contract_hash": self.record.contract_hash,
            "action_nonce": self.record.action_nonce,
            "terminal": self.record.terminal,
            "event_sequence": self.record.event_sequence,
            "html": self.html,
            "markdown": self.markdown,
        }


@dataclass(frozen=True)
class CommandWorkspaceActionResult:
    """One accepted action after its successor was stored canonically."""

    action: str
    render: CommandWorkspaceRender
    result: Mapping[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "result", dict(self.result))

    @property
    def record(self) -> CommandWorkspaceRecord:
        return self.render.record

    def to_dict(self) -> dict[str, object]:
        """Return the command-neutral action result."""
        return {
            "action": self.action,
            **self.render.to_dict(),
            "result": dict(self.result),
        }


# Where the writer takes its byte-range lock on Windows: far past any event
# file, so a reader is never refused a byte that holds data.
_LOCK_OFFSET = 1 << 40
_LOCK_RETRY_SECONDS = 2.0
# A lock the file system cannot grant at all, as against one that is busy.
_LOCK_UNSUPPORTED = frozenset(
    getattr(errno, name) for name in ("ENOLCK", "EOPNOTSUPP", "ENOTSUP", "EINVAL") if hasattr(errno, name)
)
_unsupported_lock_reported = False


def _try_lock(fd: int) -> None:
    """Take the append lock once, without waiting; raise OSError if it is held."""
    if os.name == "nt":
        import msvcrt

        os.lseek(fd, _LOCK_OFFSET, os.SEEK_SET)
        msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
    else:
        import fcntl

        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)


def _unlock(fd: int) -> None:
    if os.name == "nt":
        import msvcrt

        os.lseek(fd, _LOCK_OFFSET, os.SEEK_SET)
        msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
    else:
        import fcntl

        fcntl.flock(fd, fcntl.LOCK_UN)


@contextlib.contextmanager
def _exclusive_append(fd: int):
    """Hold the one lock that makes an append whole across processes.

    POSIX appends atomically with ``O_APPEND``, and the lock only makes the
    size check and the write one step. Windows does not: the C runtime seeks
    to the end and then writes, two steps, so two processes appending at once
    overwrite each other's lines. A byte-range lock past the end of the file
    serializes them, ``flock`` does the same elsewhere. On both, the lock is
    tried without waiting and retried for up to ``_LOCK_RETRY_SECONDS``, then
    the append fails, which the host counts as a dropped event; a blocking
    wait would stall the event loop the host runs in. A file system that
    cannot grant the lock at all (``ENOLCK``, ``EOPNOTSUPP``) gets the
    unlocked append this writer made before it had a lock, with one warning,
    rather than losing every event.
    """
    global _unsupported_lock_reported
    deadline = time.monotonic() + _LOCK_RETRY_SECONDS
    locked = False
    while True:
        try:
            _try_lock(fd)
            locked = True
            break
        except OSError as error:
            if error.errno in _LOCK_UNSUPPORTED:
                if not _unsupported_lock_reported:
                    _unsupported_lock_reported = True
                    logger.warning("Event file lock unsupported here (%s); appending unlocked", error)
                break
            if time.monotonic() >= deadline:
                raise
            time.sleep(0.005)
    try:
        yield
    finally:
        if locked:
            # Closing the descriptor releases the lock in any case; an error
            # here must not replace the refusal being unwound.
            with contextlib.suppress(OSError):
                _unlock(fd)


def jsonl_event_writer(path: Path, *, limit: int = EVENT_FILE_LIMIT) -> Callable[[dict], None]:
    """An event sink that appends one JSON line per event to ``path``.

    The file is created by the first event it accepts. A symlink, as the file
    or as its directory, is refused, and so is a file with more than one hard link,
    which would let an append land in another file such as the task record;
    once the file would pass ``limit`` bytes the event is refused, so a
    runaway host cannot fill a task directory. The host counts every refusal.
    Each append is made under a cross-process lock, so two hosts writing to
    one file never tear each other's lines and the limit is checked against
    the size the write will see. Lines are ASCII, so the byte count is exact
    and a reader that splits on newlines sees one event per line.
    """
    target = Path(path)

    def write(event: dict) -> None:
        if target.is_symlink() or target.parent.is_symlink():
            raise ValueError(f"Event file cannot be, or sit in, a symlink: {target}")
        data = (
            json.dumps(event, ensure_ascii=True, allow_nan=False, sort_keys=True) + "\n"
        ).encode("ascii")
        if len(data) > limit and not target.exists():
            # Refuse before creating the file, so a refused first event
            # leaves nothing behind.
            raise ValueError(f"Event file {target} would pass {limit} bytes")
        flags = (
            os.O_WRONLY
            | os.O_APPEND
            | os.O_CREAT
            | getattr(os, "O_NOFOLLOW", 0)
            | getattr(os, "O_BINARY", 0)
        )
        fd = os.open(target, flags, 0o600)
        try:
            with _exclusive_append(fd):
                detail = os.fstat(fd)
                if detail.st_nlink > 1:
                    raise ValueError(f"Event file cannot be a hard link: {target}")
                if detail.st_size + len(data) > limit:
                    raise ValueError(f"Event file {target} would pass {limit} bytes")
                # O_APPEND re-seeks to the end for each write on every platform
                # this runs on; do it here too, so the lock's seek can never be
                # where the line lands.
                os.lseek(fd, 0, os.SEEK_END)
                view = memoryview(data)
                while view:
                    view = view[os.write(fd, view) :]
        finally:
            os.close(fd)

    return write


class CommandWorkspaceHost:
    """Register adapters and serialize canonical workspace mutations."""

    def __init__(self, *, record_event: Callable[[dict], None] | None = None) -> None:
        self._adapters: dict[str, CommandWorkspaceAdapter] = {}
        self._records: dict[str, CommandWorkspaceRecord] = {}
        self._locks: dict[str, asyncio.Lock] = {}
        self._consumed: deque[str] = deque(maxlen=CONSUMED_IDS_KEPT)
        self._record_event = record_event
        self.dropped_events = 0

    def register(self, adapter: CommandWorkspaceAdapter) -> None:
        """Register one adapter, rejecting malformed or duplicate identity."""
        if not isinstance(adapter, CommandWorkspaceAdapter):
            raise CommandWorkspaceError(
                ["command workspace adapter does not implement the required protocol"]
            )
        if not _ADAPTER_ID_RE.fullmatch(adapter.adapter_id):
            raise CommandWorkspaceError(["command workspace adapter_id is invalid"])
        if isinstance(adapter.schema_version, bool) or not isinstance(adapter.schema_version, int):
            raise CommandWorkspaceError(
                ["command workspace adapter schema_version must be an integer"]
            )
        if adapter.schema_version < 1:
            raise CommandWorkspaceError(
                ["command workspace adapter schema_version must be positive"]
            )
        if adapter.adapter_id in self._adapters:
            raise CommandWorkspaceError(
                [f"duplicate command workspace adapter {adapter.adapter_id!r}"]
            )
        self._adapters[adapter.adapter_id] = adapter

    def adapter(self, adapter_id: str) -> CommandWorkspaceAdapter:
        """Return a registered adapter or fail explicitly."""
        adapter = self._adapters.get(adapter_id)
        if adapter is None:
            raise CommandWorkspaceError([f"unknown command workspace adapter {adapter_id!r}"])
        return adapter

    def get(self, workspace_id: str) -> CommandWorkspaceRecord | None:
        """Return the canonical record for read-only inspection.

        A workspace that reached a terminal state has been evicted and gives
        ``None``; the result returned by the call that ended it carries its
        final record.
        """
        return self._records.get(workspace_id)

    def consumed(self, workspace_id: str) -> bool:
        """Whether this id reached a terminal state and was evicted."""
        return workspace_id in self._consumed

    async def open(
        self,
        adapter_id: str,
        intake: Mapping[str, object],
        *,
        workspace_id: str | None = None,
    ) -> CommandWorkspaceRender:
        """Create a workspace or replace adapter-approved intake state."""
        if not isinstance(intake, Mapping):
            raise CommandWorkspaceError(["command workspace intake must be a mapping"])
        adapter = self.adapter(adapter_id)
        resolved_id = workspace_id or f"{adapter_id}-{uuid.uuid4().hex}"
        if resolved_id in self._consumed:
            raise CommandWorkspaceError(["terminal command workspace cannot be replaced"])
        # A lock exists only for a live record, or for the one being created
        # here; a refused id never leaves one behind.
        if workspace_id is not None and workspace_id not in self._locks:
            raise CommandWorkspaceError(["unknown command workspace_id"])
        lock = self._locks.setdefault(resolved_id, asyncio.Lock())
        try:
            async with lock:
                return self._open_locked(adapter, adapter_id, intake, workspace_id, resolved_id)
        finally:
            if resolved_id not in self._records:
                self._locks.pop(resolved_id, None)

    def _open_locked(self, adapter, adapter_id, intake, workspace_id, resolved_id):
        if resolved_id in self._consumed:
            raise CommandWorkspaceError(["terminal command workspace cannot be replaced"])
        current = self._records.get(resolved_id)
        if workspace_id is not None and current is None:
            raise CommandWorkspaceError(["unknown command workspace_id"])
        if current is not None and current.adapter_id != adapter_id:
            raise CommandWorkspaceError(
                ["command workspace adapter does not match canonical state"]
            )
        if current is not None and current.adapter_version != adapter.schema_version:
            raise CommandWorkspaceError(
                ["command workspace adapter version changed during the interaction"]
            )
        # A terminal record is never stored (see _store); this and its twins in
        # collect and publish are kept from the original as belt and braces.
        if current is not None and current.terminal:
            raise CommandWorkspaceError(["terminal command workspace cannot be replaced"])
        prior_state = copy.deepcopy(current.state) if current is not None else None
        state = adapter.create(intake, prior_state=prior_state)
        projection = adapter.project(state)
        revision = current.revision + 1 if current is not None else 0
        record = self._record(
            workspace_id=resolved_id,
            adapter=adapter,
            revision=revision,
            state=state,
            projection=projection,
            terminal=False,
            event_sequence=current.event_sequence if current is not None else 0,
        )
        self._records[resolved_id] = record
        return self._render(record)

    async def collect(
        self,
        payload: Mapping[str, object],
        *,
        expected_adapter_id: str | None = None,
    ) -> CommandWorkspaceActionResult:
        """Validate and consume one action against canonical server state."""
        if not isinstance(payload, Mapping):
            raise CommandWorkspaceError(["command workspace action response must be a mapping"])
        workspace_id = payload.get("workspace_id")
        if not isinstance(workspace_id, str):
            raise CommandWorkspaceError(["command workspace action response requires workspace_id"])
        if workspace_id in self._consumed:
            raise CommandWorkspaceError(["command workspace action authority was already consumed"])
        lock = self._locks.get(workspace_id)
        if lock is None:
            raise CommandWorkspaceError(["unknown or expired command workspace_id"])
        async with lock:
            current = self._records.get(workspace_id)
            if current is None:
                if workspace_id in self._consumed:
                    raise CommandWorkspaceError(
                        ["command workspace action authority was already consumed"]
                    )
                raise CommandWorkspaceError(["unknown or expired command workspace_id"])
            if expected_adapter_id is not None and current.adapter_id != expected_adapter_id:
                raise CommandWorkspaceError(
                    ["command workspace adapter does not match the requested tool"]
                )
            if current.terminal:
                raise CommandWorkspaceError(
                    ["command workspace action authority was already consumed"]
                )
            adapter = self.adapter(current.adapter_id)
            if current.adapter_version != adapter.schema_version:
                raise CommandWorkspaceError(
                    ["command workspace adapter version changed during the interaction"]
                )
            fresh = adapter.project(current.state)
            if fresh.view != current.view:
                raise CommandWorkspaceError(
                    ["canonical command workspace view changed after rendering"]
                )
            if not hmac.compare_digest(fresh.contract_hash, current.contract_hash):
                raise CommandWorkspaceError(
                    ["canonical command workspace contract changed after rendering"]
                )
            try:
                response = _forms().collect_workspace_action(
                    current.view,
                    payload,
                    current.binding,
                )
            except ValueError as exc:
                problems = getattr(exc, "problems", [str(exc)])
                raise CommandWorkspaceError(list(problems)) from exc
            transition = adapter.apply(copy.deepcopy(current.state), response)
            projection = adapter.project(transition.state)
            if transition.terminal and projection.view.actions:
                raise CommandWorkspaceError(
                    ["terminal command workspace view cannot expose actions"]
                )
            successor = self._record(
                workspace_id=current.workspace_id,
                adapter=adapter,
                revision=current.revision + 1,
                state=transition.state,
                projection=projection,
                terminal=transition.terminal,
                event_sequence=current.event_sequence,
            )
            self._store(successor)
            instance_id = payload.get("instance_id", "")
            self._emit(
                {
                    "event": "workspace_accepted",
                    "workspace_id": current.workspace_id,
                    "revision": current.revision,
                    "instance_id": instance_id if isinstance(instance_id, str) else "",
                    "adapter_id": current.adapter_id,
                    "action": response.action,
                    "terminal": transition.terminal,
                }
            )
            render = self._render(successor)
            return CommandWorkspaceActionResult(response.action, render, transition.result)

    async def publish(
        self,
        workspace_id: str,
        event: Mapping[str, object],
    ) -> CommandWorkspaceActionResult:
        """Publish one trusted adapter event without client action authority."""
        if not isinstance(event, Mapping):
            raise CommandWorkspaceError(["command workspace event must be a mapping"])
        if workspace_id in self._consumed:
            raise CommandWorkspaceError(["terminal command workspace cannot accept events"])
        lock = self._locks.get(workspace_id)
        if lock is None:
            raise CommandWorkspaceError(["unknown or expired command workspace_id"])
        async with lock:
            current = self._records.get(workspace_id)
            if current is None:
                if workspace_id in self._consumed:
                    raise CommandWorkspaceError(["terminal command workspace cannot accept events"])
                raise CommandWorkspaceError(["unknown or expired command workspace_id"])
            if current.terminal:
                raise CommandWorkspaceError(["terminal command workspace cannot accept events"])
            adapter = self.adapter(current.adapter_id)
            if current.adapter_version != adapter.schema_version:
                raise CommandWorkspaceError(
                    ["command workspace adapter version changed during the interaction"]
                )
            if not isinstance(adapter, CommandWorkspacePublisher):
                raise CommandWorkspaceError(
                    [f"command workspace adapter {adapter.adapter_id!r} does not accept events"]
                )
            transition = adapter.publish(copy.deepcopy(current.state), event)
            projection = adapter.project(transition.state)
            if transition.terminal and not transition.authority_changed:
                raise CommandWorkspaceError(
                    ["terminal workspace publication must change authority"]
                )
            if transition.terminal and projection.view.actions:
                raise CommandWorkspaceError(
                    ["terminal command workspace view cannot expose actions"]
                )
            if transition.authority_changed:
                successor = self._record(
                    workspace_id=current.workspace_id,
                    adapter=adapter,
                    revision=current.revision + 1,
                    state=transition.state,
                    projection=projection,
                    terminal=transition.terminal,
                    event_sequence=current.event_sequence + 1,
                )
            else:
                if (
                    projection.view.id != current.view.id
                    or projection.view.actions != current.view.actions
                    or projection.view.form != current.view.form
                    or not hmac.compare_digest(projection.contract_hash, current.contract_hash)
                ):
                    raise CommandWorkspaceError(
                        ["progress-only publication changed action authority"]
                    )
                successor = CommandWorkspaceRecord(
                    workspace_id=current.workspace_id,
                    adapter_id=current.adapter_id,
                    adapter_version=current.adapter_version,
                    revision=current.revision,
                    state=transition.state,
                    view=projection.view,
                    contract_hash=current.contract_hash,
                    action_nonce=current.action_nonce,
                    terminal=False,
                    event_sequence=current.event_sequence + 1,
                )
            self._store(successor)
            return CommandWorkspaceActionResult("publish", self._render(successor), transition.result)

    def _store(self, record: CommandWorkspaceRecord) -> None:
        """Keep a live record; evict a terminal one and remember its id."""
        if record.terminal:
            self._records.pop(record.workspace_id, None)
            self._locks.pop(record.workspace_id, None)
            self._consumed.append(record.workspace_id)
        else:
            self._records[record.workspace_id] = record

    def _emit(self, event: dict) -> None:
        """Hand one event to the sink; a failing sink is counted, never fatal."""
        if self._record_event is None:
            return
        try:
            self._record_event({"at": datetime.now(timezone.utc).isoformat(), **event})
        except Exception as exc:  # a sink is caller code; nothing it raises may block a decision
            self.dropped_events += 1
            logger.warning("Workspace event not recorded (%s): %s", event.get("event"), exc)

    @staticmethod
    def _record(
        *,
        workspace_id: str,
        adapter: CommandWorkspaceAdapter,
        revision: int,
        state: object,
        projection: CommandWorkspaceProjection,
        terminal: bool,
        event_sequence: int = 0,
    ) -> CommandWorkspaceRecord:
        needs_binding = (
            bool(projection.view.actions) and projection.view.form is None and not terminal
        )
        return CommandWorkspaceRecord(
            workspace_id=workspace_id,
            adapter_id=adapter.adapter_id,
            adapter_version=adapter.schema_version,
            revision=revision,
            state=state,
            view=projection.view,
            contract_hash=projection.contract_hash,
            action_nonce=secrets.token_urlsafe(24) if needs_binding else "",
            terminal=terminal,
            event_sequence=event_sequence,
        )

    def _render(self, record: CommandWorkspaceRecord) -> CommandWorkspaceRender:
        forms = _forms()
        binding = record.binding if record.action_nonce else None
        instance_id = uuid.uuid4().hex
        start = time.perf_counter()
        html = forms.workspace_to_widget_html(
            record.view, binding=binding, telemetry_instance_id=instance_id
        )
        if binding is not None:
            self._emit(
                {
                    "event": "workspace_rendered",
                    "workspace_id": record.workspace_id,
                    "revision": record.revision,
                    "instance_id": instance_id,
                    "adapter_id": record.adapter_id,
                    "duration_ms": round((time.perf_counter() - start) * 1000, 3),
                }
            )
        return CommandWorkspaceRender(
            record=record,
            html=html,
            markdown=forms.workspace_to_markdown(record.view, binding=binding),
        )

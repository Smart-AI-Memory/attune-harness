"""The command line's surface as data, read from the parsers themselves.

``surface()`` walks the parser ``cli.build_parser`` returns and records, for
the program and for every verb and subcommand, the positional arguments with
how many values each takes, the required options, the mutually exclusive groups
that require one member, every option string, and every argument's choices
and default. ``tests/fixtures/compatibility/surface.json`` holds the committed
form and ``docs/compatibility.md`` its table, kept in step by
``tests/test_compatibility_surface.py`` the way the envelope page is; a change
to either is a deliberate diff (the interface freeze, 4.1; D27.1). Exit codes
are behaviour, not parser data: the envelope table pins them, row by row.

Copyright 2026 Smart AI Memory, LLC
Licensed under the Apache License, Version 2.0
"""

from __future__ import annotations

import argparse
from pathlib import Path


def _subcommands(parser: argparse.ArgumentParser):
    for action in parser._actions:
        if isinstance(action, argparse._SubParsersAction):
            return action
    return None


# The positional arities the surface records and the table renders: exactly one, "?", "*" and "+".
_ARITIES = (None, "?", "*", "+")


def _long(action: argparse.Action) -> str:
    return sorted(action.option_strings, key=len)[-1]


def _positional(action: argparse.Action) -> dict:
    """A positional and its arity: ``nargs`` is null for exactly one, else argparse's ``?``, ``*``, ``+`` or a count.

    Recorded so that an optional positional made required, or the reverse,
    changes the surface (second review of #124, S1). An arity this module
    does not render (argparse's ``REMAINDER`` or ``PARSER``, a count) is
    refused rather than shown wrongly, so adding one fails the surface test
    and this function is extended on purpose.
    """
    if action.nargs not in _ARITIES:
        raise ValueError(f"cli_surface does not describe positional {action.dest!r} with nargs={action.nargs!r}")
    return {"name": action.dest, "nargs": action.nargs}


def _shown(positional: dict) -> str:
    """A positional as the verb table shows it: ``[name]`` optional, ``name ...`` one or more."""
    name, nargs = positional["name"], positional["nargs"]
    if nargs is None:
        return f"`{name}`"
    if nargs == "?":
        return f"`[{name}]`"
    if nargs == "*":
        return f"`[{name} ...]`"
    return f"`{name} ...`"  # "+", the one arity left


def _value(value, *, cwd_default=False):
    """JSON-safe argument value; preserve Path identity and the one dynamic cwd default."""
    if isinstance(value, Path):
        if cwd_default and value == Path.cwd():
            return {"kind": "cwd"}
        return {"kind": "path", "value": str(value)}
    if value is None or type(value) in (str, bool, int, float):
        return value
    if isinstance(value, (list, tuple)):
        return [_value(item) for item in value]
    raise ValueError(f"cli_surface does not describe argument value {value!r}")


def describe(parser: argparse.ArgumentParser, *, command_path: tuple[str, ...] = ()) -> dict:
    """One parser: argument identity, choices/defaults, arity, groups and options."""
    commands = _subcommands(parser)
    positionals: list[dict] = []
    required: list[str] = []
    options: list[str] = []
    arguments: list[dict] = []
    for action in parser._actions:
        if action is commands or isinstance(action, argparse._HelpAction):
            continue
        if action.option_strings:
            options.extend(action.option_strings)
            if action.required:
                required.append(_long(action))
        else:
            positionals.append(_positional(action))
        arguments.append({
            "name": action.dest,
            "option_strings": sorted(action.option_strings),
            "choices": None if action.choices is None else _value(list(action.choices)),
            "default": _value(action.default, cwd_default=(command_path == ("spec", "intake")
                                                   and action.dest == "project")),
        })
    one_of = sorted(
        sorted(_long(action) for action in group._group_actions)
        for group in parser._mutually_exclusive_groups
        if group.required
    )
    entry: dict = {
        "positionals": positionals,
        "required_options": sorted(required),
        "one_of": one_of,
        "options": sorted(options),
        "arguments": sorted(arguments, key=lambda item: item["name"]),
    }
    if commands is not None:
        entry["subcommands"] = {name: describe(sub, command_path=(*command_path, name))
                                for name, sub in sorted(commands.choices.items())}
    return entry


def surface() -> dict:
    """The whole command line, as the compatibility fixture stores it."""
    from .cli import build_parser

    top = describe(build_parser())
    return {
        "schema_version": 1,
        "program": "attune-harness",
        "options": top["options"],
        "arguments": top["arguments"],
        "verbs": top["subcommands"],
    }


def _tree(entry: dict) -> str:
    subs = entry.get("subcommands") or {}
    return " ".join(
        name + (f"({_tree(sub)})" if sub.get("subcommands") else "") for name, sub in subs.items()
    )


def rows(value: dict) -> list[str]:
    """The Markdown rows of the verb table in ``docs/compatibility.md``."""
    out = []
    for verb, entry in value["verbs"].items():
        subs = _tree(entry) or "-"
        positionals = " ".join(_shown(positional) for positional in entry["positionals"]) or "-"
        parts = [f"`{option}`" for option in entry["required_options"]]
        parts += ["one of " + ", ".join(f"`{option}`" for option in group) for group in entry["one_of"]]
        out.append(f"| `{verb}` | {subs} | {positionals} | {' '.join(parts) or '-'} |")
    return out

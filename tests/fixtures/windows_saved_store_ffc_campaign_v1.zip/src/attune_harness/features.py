"""Optional local feature contracts; importing this module needs no extras."""

import importlib
import json
import os
import re
import tempfile
import time
from importlib.metadata import PackageNotFoundError, requires, version
from pathlib import Path
from uuid import uuid4


class FeatureUnavailable(RuntimeError):
    """A selected optional capability is absent or not the qualified version."""


# Names that were extras before 0.4.0 and are part of the base install now.
# A missing one means the package was installed without its dependencies.
BASE_EXTRAS = frozenset({'tokens', 'verify', 'rag', 'review', 'mcp'})


def require_feature(distribution: str, module: str, expected: str, extra: str):
    """Load only the explicitly selected, version-qualified integration."""
    try:
        installed = version(distribution)
    except PackageNotFoundError as exc:
        if extra in BASE_EXTRAS:
            hint = f"{distribution} is missing; reinstall with: pip install --force-reinstall attune-harness"
        else:
            hint = f"Install attune-harness[{extra}]; {distribution} is missing"
        raise FeatureUnavailable(hint) from exc
    if installed != expected:
        raise FeatureUnavailable(f"{distribution} {installed} is unsupported; install {distribution}=={expected}")
    try:
        return importlib.import_module(module)
    except ImportError as exc:
        raise FeatureUnavailable(f"{distribution} cannot load: {exc}") from exc


def report(operation: str, status: str, **fields) -> dict:
    """Tool-operation envelope, separate from model task completion receipts."""
    return {"schema_version": 1, "request_id": str(uuid4()),
            "operation": operation, "status": status, **fields}


def deprecation_entry(entry: dict) -> dict:
    """Validate one active compatibility notice and return an independent value."""
    keys = {'surface', 'form', 'since', 'removal', 'replacement'}
    if (not isinstance(entry, dict) or set(entry) != keys
            or any(not isinstance(value, str) or not value.strip() for value in entry.values())):
        raise ValueError('Deprecation requires surface, form, since, removal and replacement')
    versions = []
    for name in ('since', 'removal'):
        if not re.fullmatch(r'(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)', entry[name]):
            raise ValueError('Deprecation versions must be stable major.minor.patch versions')
        versions.append(tuple(int(part) for part in entry[name].split('.')))
    since, removal = versions
    if removal < (since[0], since[1] + 1, 0):
        raise ValueError('Deprecation must retain the old form for at least one minor release')
    return dict(entry)


def with_deprecation(envelope: dict, entry: dict) -> dict:
    """Add a notice only on the caller's deprecated-form path (D27.3).

    Current forms keep their envelope unchanged. Callers retain the old behavior
    and select an entry from the documented register; this helper never redirects
    a command or removes a form. No caller-owned dictionary or list is mutated.
    """
    notice = deprecation_entry(entry)
    notices = [deprecation_entry(value) for value in envelope.get('deprecations', [])]
    if notice not in notices:
        notices.append(notice)
    return {**envelope, 'deprecations': notices}


OVERSIZE = "Input exceeds its limit"


def read_text(path: Path, limit: int = 4 * 1024 * 1024) -> str:
    """Read bounded, regular UTF-8 input; never truncate it into valid evidence."""
    if not path.is_file():
        raise ValueError(f"Not a regular input file: {path}")
    with path.open('rb') as stream:
        raw = stream.read(limit + 1)
        if len(raw) > limit:
            # Another writer may shrink the file after the read. Never report
            # a size smaller than what was read.
            size = max(os.fstat(stream.fileno()).st_size, len(raw))
            raise ValueError(
                f"{OVERSIZE} of {limit} bytes; it is {size} bytes: {path}. "
                "It was refused whole. Harness never shortens an input to fit.")
    return raw.decode('utf-8')


def output_path(path: Path, protected: tuple[Path, ...] = ()) -> Path:
    """Refuse destructive destinations before running a feature or writing."""
    if path.is_symlink():
        raise ValueError("Output cannot be a symlink")
    target = path.resolve()
    if target.suffix.lower() != '.json':
        raise ValueError("Output must be a .json report")
    if any(part in {'.git', '.hg', '.svn'} for part in target.parts):
        raise ValueError("Output cannot target repository metadata")
    if target in {item.resolve() for item in protected}:
        raise ValueError("Output must not overwrite an input")
    if not target.parent.is_dir() or (target.exists() and not target.is_file()):
        raise ValueError("Output requires an existing directory and regular file destination")
    return target


def _version_tuple(text: str):
    parts = []
    for piece in text.strip().split('.'):
        if not piece.isdigit():
            return None
        parts.append(int(piece))
    return tuple(parts)


def _satisfied(installed: str, spec: str):
    """Whether ``installed`` meets one comma-separated PEP 440 spec; None when unsure."""
    have = _version_tuple(installed)
    if have is None:
        return None
    for clause in spec.split(','):
        clause = clause.strip()
        for operator in ('===', '==', '!=', '<=', '>=', '<', '>', '~='):
            if clause.startswith(operator):
                wanted = _version_tuple(clause[len(operator):].rstrip('.*'))
                if wanted is None or operator in ('===', '~=') or clause.endswith('.*'):
                    return None
                ok = {'==': have == wanted, '!=': have != wanted, '<=': have <= wanted,
                      '>=': have >= wanted, '<': have < wanted, '>': have > wanted}[operator]
                if not ok:
                    return False
                break
        else:
            return None
    return True


def neighbor_conflict(dependency: str = 'mcp', neighbor: str = 'attune-ai') -> str | None:
    """A notice when a co-installed neighbour pins ``dependency`` to a line this install replaced.

    Harness and attune-ai pin different lines of the MCP SDK, so one environment
    cannot hold both working. pip installs the second anyway and exits 0. This
    names the breakage at the moment it matters; it never changes behaviour.
    Returns None when the neighbour is absent, its requirement is met, or the
    requirement cannot be read with certainty.
    """
    try:
        installed = version(dependency)
        declared = requires(neighbor) or []
    except PackageNotFoundError:
        return None
    for requirement in declared:
        name, _, rest = requirement.partition(';')
        head = name.strip()
        for cut in ('===', '==', '!=', '<=', '>=', '<', '>', '~=', ' ', '['):
            if cut in head:
                head = head[:head.index(cut)]
        if head.strip().lower() != dependency.lower() or ';' in requirement and 'extra' in rest:
            continue
        spec = name.strip()[len(head):].strip().strip('()')
        if spec and _satisfied(installed, spec) is False:
            return (f"{neighbor} is installed here and requires {dependency}{spec}, but "
                    f"attune-harness installed {dependency} {installed}; the two cannot share an "
                    f"environment. Install attune-harness in its own environment "
                    f"(pipx install attune-harness) and reinstall {neighbor}.")
    return None


REPLACE_RETRY_SECONDS = 2.0
# Whether a replace refused with PermissionError is retried: the Windows
# sharing refusal. A module flag rather than os.name at call time, so a test
# can exercise the retry on every platform without touching os.name.
RETRY_REFUSED_REPLACE = os.name == 'nt'


def replace_file(source: Path, target: Path, *, retry_seconds: float = REPLACE_RETRY_SECONDS) -> None:
    """Atomic replace. A reader briefly holding the target must not fail the writer.

    Windows refuses to replace a file while another handle has it open (a
    reader of the same record, an indexer, antivirus). Retry for a bounded
    period, then fail as before. POSIX replaces over an open file at once.
    """
    if not RETRY_REFUSED_REPLACE:
        os.replace(source, target)
        return
    deadline = time.monotonic() + retry_seconds
    while True:
        try:
            os.replace(source, target)
            return
        except PermissionError:
            if time.monotonic() >= deadline:
                raise
            time.sleep(.005)


def write_report(path: Path, value: dict, protected: tuple[Path, ...] = ()) -> None:
    """Atomically publish JSON locally; caller explicitly chooses the path."""
    target = output_path(path, protected)
    payload = json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + '\n'
    name = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=target.parent, delete=False) as stream:
            name = stream.name
            stream.write(payload)
        replace_file(Path(name), target)
    finally:
        if name is not None and Path(name).exists():
            Path(name).unlink()

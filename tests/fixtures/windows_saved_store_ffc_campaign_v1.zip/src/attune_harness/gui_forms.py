"""Browser controls for owner-selected forms; all untrusted text uses textContent."""

FORM_PAGE = ('<section id="decisions" hidden aria-labelledby="decision-heading">'
             '<div><p class="eyebrow">CONNECTED JOURNEY · INTENT → BUILD → EVIDENCE</p>'
             '<h1 id="decision-heading">Continue saved work</h1>'
             '<p>Harness chooses the form from saved work. Saving answers keeps a draft. '
             'Approving the work request records your decision only; it does not start the work.</p></div>'
             '<div id="tasks"></div><div id="form-panel"></div></section>')

FORM_STYLE = """
#decisions{padding:24px;max-width:1040px;margin:auto}
h1{font-size:28px;margin:8px 0}h2{font-size:20px}.eyebrow{font-size:11px;letter-spacing:.09em}
#tasks{display:flex;gap:12px;flex-wrap:wrap;margin:20px 0}
.task-card{background:white;border:1px solid #dce4da;border-radius:10px;padding:16px;flex:1;min-width:220px}
.task-card p{margin:8px 0;overflow-wrap:anywhere}.task-card h2{margin:0;overflow-wrap:anywhere}
#form-panel:not(:empty){background:white;border:1px solid #b8cdbb;border-radius:12px;padding:24px}
fieldset{border:0;margin:0;padding:0}label{display:block;margin:16px 0 6px;font-weight:600}
textarea,select{box-sizing:border-box;width:100%;padding:10px;border:1px solid #869a8a;border-radius:6px;font:inherit;background:white;color:#263c30}
textarea{min-height:86px;resize:vertical}select{white-space:normal}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:14px/1.55 system-ui;background:#f5f6f2;padding:16px;border-radius:6px}
.action-row{border-top:1px solid #dce4da;margin-top:16px;padding-top:16px}.action-row p{margin-bottom:8px}
button{cursor:pointer}button:disabled{opacity:.5;cursor:default}button:focus-visible,textarea:focus-visible,select:focus-visible{outline:3px solid #c18529;outline-offset:3px}
#form-panel button{margin-top:12px}#form-panel small{display:block;margin:8px 0;color:#4b6353}
@media(max-width:600px){#decisions{padding:16px}#form-panel:not(:empty){padding:16px}header{padding:12px 16px}}
"""

FORM_SCRIPT = r"""
const panel=document.querySelector('#form-panel'),tasks=document.querySelector('#tasks');
let busy=false,expired=false;
function expirePanel(){
 expired=true;stopBuildWatch();
 if(!panel.children.length)return;
 for(const input of panel.querySelectorAll('textarea'))input.readOnly=true;
 for(const control of panel.querySelectorAll('button,select'))control.disabled=true;
 const answers=Array.from(panel.querySelectorAll('textarea,select')).filter(input=>input.value).map(input=>(input.getAttribute('data-recovery-label')||input.name)+': '+input.value);
 if(answers.length&&!panel.querySelector('.retained-answers')){const recovery=node('pre',answers.join('\n\n'),panel);recovery.className='retained-answers';recovery.setAttribute('aria-label','Retained answers for copying');}
 if(!panel.querySelector('.expired-notice')){const notice=node('p','Retained for copying only. This form has expired. Refresh saved state, then deliberately open the current form or preview; answers are never replayed.',panel);notice.className='expired-notice';notice.setAttribute('role','status');}
}
const buildCards=new Map();
function node(tag,text,parent){const el=document.createElement(tag);if(text!==undefined)el.textContent=text;if(parent)parent.append(el);return el;}
async function api(path,payload){
 const res=await fetch(path,{method:payload?'POST':'GET',headers:{'X-Attune-Session':token||'',...(payload?{'Content-Type':'application/json'}:{})},...(payload?{body:JSON.stringify(payload)}:{}),cache:'no-store'});
 if(!res.ok)throw Error(await res.text());return await res.json();
}
async function loadTasks(){
 try{const data=await api('/workspace');tasks.replaceChildren();buildCards.clear();document.querySelector('#decisions').hidden=!data.editable;
 for(const task of data.tasks){
  const card=node('article',undefined,tasks);card.className='task-card';node('h2',task.label,card);node('p',task.status+(task.status==='accepted'&&task.build?' · Intent accepted': ' · '+task.note),card);
  if(task.build){
   const build=task.build,note=node('p','',card),error=node('p','',card);
   if(build.view){const inspect=node('button','Inspect progress and evidence',card);inspect.type='button';inspect.onclick=()=>watchBuild(task.task);}
   const preview=node('button','Preview command build',card);preview.type='button';
   buildCards.set(task.task,{note,error,preview});updateBuildCard(task);
  }
  if(task.available){const open=node('button','Open current form',card);open.type='button';open.onclick=()=>act(async()=>{
   const shown=await api('/decision/open',{task:task.task,checkpoint:task.checkpoint});renderDecision(shown);
   status.textContent='Current decision retained. Review before responding.';
  });}
 }
 return true;
 }catch(e){status.textContent='Decision inspection failed. '+e.message;return false;}
}
function updateBuildCard(task){
 const card=buildCards.get(task.task),build=task.build;if(!card||!build)return;
 card.note.textContent=build.note;card.error.hidden=!build.error;
 card.error.textContent=build.error?'Last command attempt: '+build.error:'';
 card.preview.hidden=!build.available;
 card.preview.onclick=()=>act(async()=>renderBuildGrant(await api('/build/preview',{task:task.task,checkpoint:task.checkpoint})));
}
async function act(operation){
 if(busy)return;busy=true;const disabled=new Map(Array.from(document.querySelectorAll('button'),b=>[b,b.disabled]));disabled.forEach((_,b)=>b.disabled=true);
 try{await operation();}catch(e){expirePanel();status.textContent='Action not confirmed. '+e.message+' Refresh saved state before continuing.';}
 finally{busy=false;document.querySelectorAll('button').forEach(b=>b.disabled=(expired&&panel.contains(b))||disabled.get(b)||false);}
}
async function submit(shown,response){
 if(expired)return;
 expirePanel();
 const result=await api('/decision/submit',{task:shown.task,checkpoint:shown.checkpoint,decision:shown.decision,response});
 await refreshWorkspace(result.message);
}
async function refreshWorkspace(message=''){
 expirePanel();
 const fresh=await refresh();const snapshotWarning=fresh?'':status.textContent;
 const loaded=await loadTasks();const decisionWarning=loaded?'':status.textContent;
 status.textContent=[message|| (fresh?'Snapshot refreshed. Inspection makes no decisions or model calls.':''),snapshotWarning,decisionWarning].filter(Boolean).join(' ');
}
function renderDecision(shown){
 stopBuildWatch();expired=false;
 panel.replaceChildren();const display=shown.display;
 const title=node('h2',display.kind==='spec'?'Review draft intent':display.title,panel);title.tabIndex=-1;title.focus();
 node('small','Bound to checkpoint '+shown.checkpoint.slice(0,12)+'. Opening another form or restarting expires this decision.',panel);
 if(display.kind==='spec'){
  const summary=shown.summary,intent=summary.intent;
  node('h3','Goal',panel);node('p',intent.goal,panel);
  for(const [key,label] of [['scope','Files in scope'],['acceptance','Done when'],['constraints','Constraints'],['context','Context']]){
   if(intent[key].length){node('h3',label,panel);const list=node('ul',undefined,panel);for(const item of intent[key])node('li',item,list);}
  }
  for(const question of intent.questions){
   node('h3',question.question,panel);
   node('small',question.material?'Required for acceptance':'Optional question',panel);
   node('p',question.answer===null?'Not answered':question.answer,panel);
  }
  for(const choice of summary.choices){
   node('h3',choice.question,panel);const option=choice.options.find(o=>o.id===choice.selected);
   node('p',option?option.proposal:'Undecided',panel);
   if(option){node('p','Rationale: '+option.rationale+' Counter-case: '+option.counter_case,panel);}
  }
  node('small','Authoring format: '+summary.authoring.tier,panel);
  if(summary.effects){const effects=node('details',undefined,panel);node('summary','Configured file effects and checks',effects);node('pre',JSON.stringify(summary.effects,null,2),effects);}
 }
 const details=node('details',undefined,panel);node('summary','Read retained owner decision',details);node('pre',display.markdown,details);
 if(display.kind==='questions'){
  const instructions=node('p','Answer what you know. You can save partial answers; Harness will ask only what remains.',panel);instructions.id='answer-instructions';
  const form=node('form',undefined,panel),inputs=[];
  for(const field of display.definition.fields){
   const id='field-'+field.id;const label=node('label',field.text,form);label.htmlFor=id;
   let input;
   if(field.type==='single_select'){input=node('select',undefined,form);node('option','Choose an option…',input).value='';
    for(const text of field.options){node('option',text,input).value=text;}
   }else if(field.type==='text_input'){input=node('textarea',undefined,form);}
   else{node('p','This field requires the CLI collector.',form);return;}
   input.id=id;input.name=field.id;input.setAttribute('data-recovery-label',field.text);inputs.push([field.id,input]);
   const hint=node('small',(field.required===true?'Required before intent acceptance. ':'')+'You can leave this blank when saving partial answers.',form);hint.id=id+'-hint';
   input.setAttribute('aria-describedby',instructions.id+' '+hint.id);
  }
  const save=node('button','Save answers',form);save.type='submit';
  form.onsubmit=e=>{e.preventDefault();if(expired)return;const answers=Object.fromEntries(inputs.filter(([,input])=>input.value.trim()).map(([key,input])=>[key,input.value]));
   if(!Object.keys(answers).length){status.textContent='Enter at least one answer to save.';return;}
   act(()=>submit(shown,{answers}));};
 }else{
  // Owner markdown contains the actual intent, readiness and review evidence.
  details.open=display.actions.length===0;
  node('p','Review this work request, then choose whether to approve it or keep it as a draft. Neither option starts the work.',panel);
  for(const action of display.actions){
   const row=node('div',undefined,panel);row.className='action-row';
   const consequences={approve_task:'Approve the work request shown in this review, including its goal, success criteria, scope, context, constraints, and recorded choices. This records your approval only. It does not start the work.',redo_task:'Keep this work request as an unapproved draft so you can reconsider it. This does not start the work.'};
   node('p',consequences[action.id]||action.consequence||'Record this response to the current decision.',row);
   const labels={approve_task:'Approve this work request',redo_task:'Keep as draft'};
   const choose=node('button',labels[action.id]||action.label,row);choose.type='button';
   choose.onclick=()=>act(()=>submit(shown,{action:action.id,confirmed:true}));
  }
  if(!display.actions.length)node('p','The owner has no available action. Inspect the blocking evidence above.',panel);
 }
}

let watchedBuild=null,buildTimer=null,watchRevision=0,evidenceNodes=null;
function stopBuildWatch(){watchRevision++;watchedBuild=null;clearTimeout(buildTimer);evidenceNodes=null;}
async function watchBuild(task,focus=true){
 stopBuildWatch();watchedBuild=task;const revision=watchRevision;
 async function poll(){
  try{const data=await api('/workspace');if(watchedBuild!==task||revision!==watchRevision)return;
  for(const item of data.tasks)updateBuildCard(item);
  const build=data.tasks.find(item=>item.task===task)?.build;
  if(!build?.view)throw Error(build?.note||'Task inspection unavailable');
  renderBuildEvidence(build,focus);focus=false;
  if(build.running)buildTimer=setTimeout(poll,1000);
  }catch(e){if(watchedBuild===task&&revision===watchRevision){node('p','Progress inspection failed. '+e.message+' Refresh before acting; no execution was retried.',panel);stopBuildWatch();}}
 }
 await poll();
}
function renderBuildEvidence(build,focus=true){
 const view=build.view;
 if(!evidenceNodes){
  expired=false;panel.replaceChildren();
  const heading=node('h2','Recorded progress and evidence',panel);heading.tabIndex=-1;if(focus)heading.focus();
  evidenceNodes={summary:node('p','',panel),note:node('p','',panel),next:node('p','',panel),completed:node('p','',panel),evidence:node('pre','',panel),reviewsHeading:node('h3','Recorded reviewer findings',panel),reviews:node('pre','',panel)};
  node('small','Reviewer output is evidence to inspect, not human acceptance. Refresh reads saved state and never repeats execution.',panel);
 }
 const values={summary:view.summary,note:build.note,next:'Next: '+view.next_action,completed:'Completed steps: '+(view.completed.join(', ')||'None recorded'),evidence:JSON.stringify(view.evidence,null,2),reviews:JSON.stringify(build.reviews||[],null,2)};
 const scroll=[window.scrollX,window.scrollY,panel.scrollLeft,panel.scrollTop];
 const selection=window.getSelection();
 let anchor=selection?.anchorNode,focusNode=selection?.focusNode;
 let anchorOffset=selection?.anchorOffset,focusOffset=selection?.focusOffset,restoreSelection=false;
 for(const [key,value] of Object.entries(values)){
  const el=evidenceNodes[key];if(el.textContent===value)continue;
  const ownsAnchor=anchor&&el.contains(anchor),ownsFocus=focusNode&&el.contains(focusNode);
  el.textContent=value;
  if(ownsAnchor){anchor=el.firstChild||el;anchorOffset=Math.min(anchorOffset,value.length);restoreSelection=true;}
  if(ownsFocus){focusNode=el.firstChild||el;focusOffset=Math.min(focusOffset,value.length);restoreSelection=true;}
 }
 if(restoreSelection&&anchor&&focusNode)selection.setBaseAndExtent(anchor,anchorOffset,focusNode,focusOffset);
 panel.scrollLeft=scroll[2];panel.scrollTop=scroll[3];window.scrollTo(scroll[0],scroll[1]);
 evidenceNodes.reviews.hidden=evidenceNodes.reviewsHeading.hidden=!build.reviews?.length;
}
function renderBuildGrant(shown){
 stopBuildWatch();expired=false;
 panel.replaceChildren();const heading=node('h2',shown.resume?'Resume accepted command build':'Run accepted command build',panel);heading.tabIndex=-1;heading.focus();
 node('p',shown.goal,panel);
 node('p','This grants the configured commands and accepted file effects. Commands can access their host resources; they are not guaranteed offline. Native/provider adapters are unavailable in this GUI slice.',panel);
 for(const [label,value] of [['Participants and commands',shown.participants],['Accepted tasks',shown.tasks],['File effects and protected checks',shown.effects],['Budgets',shown.budgets]]){node('h3',label,panel);node('pre',JSON.stringify(value,null,2),panel);}
 const confirm=node('button',shown.resume?'Grant resume of these commands':'Grant these commands and build',panel);confirm.type='button';
 confirm.onclick=()=>act(async()=>{if(expired)return;expirePanel();const result=await api('/build/start',{task:shown.task,checkpoint:shown.checkpoint,grant:shown.grant,confirmed:true});await refreshWorkspace(result.message);await watchBuild(shown.task);});
}
refreshWorkspace();
"""

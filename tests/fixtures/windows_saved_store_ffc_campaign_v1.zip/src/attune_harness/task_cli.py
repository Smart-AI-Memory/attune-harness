"""Task intake and unbound form templates; no participant execution lives here."""

import copy
import json
from pathlib import Path
import sys
import time

from .review_contract import parse_json
from .task_contract import (accept_task, answer_names, check_fresh, create_task,
                            clear_template_cache, form_revision, read_task, task_template)

def present_task(directory, *, bypass=False):
    started = time.perf_counter_ns()
    record = read_task(directory)
    loaded = time.perf_counter_ns()
    check_fresh(record)
    validated = time.perf_counter_ns()
    request = record['request']
    template, metrics = task_template(request, bypass=bypass)
    metrics['reused_answer_fields'] = sum(v is not None for v in request['answers'].values())
    metrics['record_validation_ms'] = (loaded - started) / 1e6
    metrics['source_validation_ms'] = (validated - loaded) / 1e6
    submission = None
    if record['status'] == 'draft':
        submission = {'schema_version': 1, 'task_id': request['task_id'], 'revision': request['revision'],
                      'form_revision': form_revision(request, template['definition']),
                      'checkpoint_digest': record['checkpoint_digest'],
                      'accepted': False, 'answers': copy.deepcopy(request['answers']),
                      'permissions': {'external': False, 'provider': False}}
    return {'schema_version': 1, 'operation': 'task-intake', 'status': record['status'],
            'task_id': request['task_id'], 'revision': request['revision'],
            'task_directory': str(Path(record['record_path']).parent),
            'answers': copy.deepcopy(request['answers']),
            'repair_contract': copy.deepcopy(request.get('repair')),
            'definition': template['definition'], 'markdown': template['markdown'],
            'submission': submission, 'defaults_origin': request['defaults_origin'],
            'intake_metrics': metrics, 'execution_status': record['status'] if 'execution' in record else 'not_started',
            'note': ('Saved execution exists; use status for its evidence.' if 'execution' in record else
                     'Intake only: no assessment or participant invocation has occurred.')}


def add_arguments(parser):
    parser.add_argument('--pause-after', type=int, help='Pause after this many new durable operations')
    parser.add_argument('--intake-only', action='store_true', help='Prepare/accept without executing')
    parser.add_argument('--goal', help='Start task-oriented assessment intake instead of legacy review JSON')
    parser.add_argument('--project', type=Path, help='Task project root (default: current directory)')
    parser.add_argument('--plan', choices=('solo', 'independent-review'))
    parser.add_argument('--task-dir', type=Path, help='Explicit new task directory outside the selected corpus')
    parser.add_argument('--task-response', type=Path, help='Submit the bound intake response for --task-dir')
    parser.add_argument('--profile', type=Path, help='Explicit saved non-sensitive project defaults')
    for name in ('criteria', 'query', 'document', 'context', 'corpus', 'assessor', 'reviewer'):
        parser.add_argument('--' + name)
    parser.add_argument('--accept', action='store_true', help='Explicitly accept the current complete intake')
    parser.add_argument('--repair-findings', action='store_true',
                        help='Require structured assessment findings eligible for explicit repair handoff')
    parser.add_argument('--bypass-intake-cache', action='store_true')
    parser.add_argument('--clear-intake-cache', action='store_true')


REVIEW_MODES = ('See attune-harness review --help: start new work with --goal, answer a saved intake with '
                '--task-dir and --task-response, or run a legacy review with REQUEST and --run-dir')
FIX_MODES = ('See attune-harness fix --help: start a repair with --goal, --checkout, --scope and --probe '
             "(the CLI guide's Scoped repair section shows a probe), or answer a saved intake with "
             '--task-dir and --task-response')
FINDINGS = 'Name the completed assessment with --from-assessment and each selected finding with its own --finding-id'
INSPECT = ('Inspect the error. If a task directory was created, read it with attune-harness status '
           'before running anything again')


def refuse(detail, next_action):
    """A rejected combination of valid options: one refusal envelope, then exit 2 as argparse did (R2)."""
    print(json.dumps({'schema_version': 1, 'operation': 'task-intake', 'status': 'failed',
                      'error': {'type': 'UsageError', 'detail': detail}, 'next_action': next_action}, indent=2))
    raise SystemExit(2)


def validate_mode(args, parser):
    task = args.goal is not None or args.task_response is not None
    names = ('project', 'plan', 'task_dir', 'profile', 'criteria', 'query', 'document',
             'context', 'corpus', 'assessor', 'reviewer', 'accept',
             'repair_findings', 'bypass_intake_cache', 'clear_intake_cache', 'intake_only', 'pause_after')
    if task:
        if args.request is not None or args.run_dir is not None or args.max_operations is not None:
            refuse('Task intake and legacy request/--run-dir/--max-operations are mutually exclusive', REVIEW_MODES)
        if args.goal is not None and args.task_response is not None:
            refuse('--goal and --task-response are mutually exclusive', REVIEW_MODES)
        if args.task_response is not None:
            forbidden = tuple(n for n in names if n not in ('task_dir', 'bypass_intake_cache', 'clear_intake_cache', 'intake_only', 'pause_after'))
            if args.task_dir is None or any(getattr(args, n) is not None and getattr(args, n) is not False for n in forbidden):
                refuse('--task-response requires --task-dir and cannot be combined with intake overrides', REVIEW_MODES)
            if args.allow_external or args.allow_provider:
                refuse('A task response must carry its own explicit permissions', REVIEW_MODES)
            if args.config is not None:
                refuse('A task response uses its saved registry; --config cannot override it', REVIEW_MODES)
    else:
        if args.request is None or args.run_dir is None:
            refuse('Legacy review requires request and --run-dir; new intake requires --goal', REVIEW_MODES)
        if any(getattr(args, n) is not None and getattr(args, n) is not False for n in names):
            refuse('Task intake options require --goal or --task-response', REVIEW_MODES)
    args.config = args.config or Path('participants.json')
    return task


def execute_intake(args):
    """The accepted-intake result is deliberately distinct from completed review."""
    try:
        if args.clear_intake_cache:
            clear_template_cache()
        if args.task_response is not None:
            saved = read_task(args.task_dir)
            if (args.command == 'fix') != ('repair' in saved['request']):
                raise ValueError('Task response belongs to another task policy')
            from .features import read_text
            response = parse_json(read_text(args.task_response, 131072))
            record = accept_task(args.task_dir, response)
            directory = Path(record['record_path']).parent
        else:
            from .init_cli import require_registry
            require_registry(args.config, args.project)
            if args.command == 'fix':
                from .task_contract import create_repair_task
                from .features import read_text
                record = create_repair_task(args.project or Path.cwd(), args.config, goal=args.goal,
                    checkout=args.checkout, allowed=args.scope, probe=parse_json(read_text(args.probe,65536)),
                    worker=args.worker, criteria=args.criteria, reviewer=args.reviewer, review=args.review,
                    directory=args.task_dir, source_assessment=args.from_assessment,
                    finding_ids=args.finding_ids)
            else:
                names = answer_names(args.plan or 'solo')
                if args.reviewer is not None and 'reviewer' not in names:
                    raise ValueError('--reviewer requires --plan independent-review')
                answers = {n: getattr(args, n) for n in names if n != 'goal' and getattr(args, n) is not None}
                record = create_task(args.project or Path.cwd(), args.config, goal=args.goal,
                                     plan=args.plan or 'solo', directory=args.task_dir,
                                     answers=answers, profile=args.profile,
                                     result_profile=('assessment-findings-v1'
                                                     if args.repair_findings else None))
            directory = Path(record['record_path']).parent
            presented = present_task(directory, bypass=args.bypass_intake_cache)
            response = presented['submission']
            response['permissions'] = {'external': args.allow_external, 'provider': args.allow_provider}
            if sys.stdin.isatty() and not args.accept:
                print(presented['markdown'])
                for name, value in response['answers'].items():
                    if value is None:
                        response['answers'][name] = input(name + ': ').strip()
                print(json.dumps({'answers': response['answers'], 'permissions': response['permissions'],
                                  'repair_contract': presented['repair_contract']}, indent=2))
                response['accepted'] = input('Accept this intake? [y/N] ').strip().lower() in ('y', 'yes')
            elif args.accept:
                response['accepted'] = True
            if response['accepted']:
                accept_task(directory, response)
        result = present_task(directory, bypass=args.bypass_intake_cache)
        if result['status'] == 'accepted' and not args.intake_only:
            from .task_policies import execute_task
            result = execute_task(directory, max_operations=args.pause_after)
        print(json.dumps(result, ensure_ascii=False, allow_nan=False, indent=2))
        return 0 if result['status'] in ('accepted', 'completed') else (1 if result['status'] in ('draft', 'paused') else 2)
    except Exception as exc:
        failure = {'schema_version': 1, 'operation': 'task-intake', 'status': 'failed',
                   'error': {'type': type(exc).__name__, 'detail': str(exc)}}
        failure['next_action'] = getattr(exc, 'next_action', None) or INSPECT
        print(json.dumps(failure, indent=2))
        return 2


def add_controls(sub):
    for name, help_text in (
        ('status', 'Inspect a saved task'),
        ('resume', 'Continue a saved task'),
        ('reconcile-task', 'Attach a correlated reply or authorize one known read-only retry'),
        ('transfer-task', 'Transfer an assessor to an already accepted identity'),
        ('cancel-task', 'Cancel stopped work while preserving uncertain effects'),
    ):
        parser = sub.add_parser(name, help=help_text)
        parser.add_argument('task_dir', type=Path)
        if name == 'status':
            parser.add_argument('--format', choices=('json', 'markdown', 'html'), default='json',
                                help='Output format; human-readable snapshots require feature work')
            parser.add_argument('--include-task', type=Path, action='append', default=[],
                                help='Additional explicit saved task for an HTML/Markdown task list (20 total)')
            parser.add_argument('--continuation', type=Path,
                                help='Explicit continuation JSON for --format markdown or html')
        if name != 'status':
            parser.add_argument('--checkpoint', help='Optional expected checkpoint for scripted compare-and-set')
        if name == 'resume':
            from .human_output import add_format
            add_format(parser)
            parser.add_argument('--max-operations', type=int)
            parser.add_argument('--allow-external', action='store_true', help='Explicit feature-work command dispatch')
            parser.add_argument('--allow-native', action='store_true', help='Separate feature-work native trial authorization')
        elif name == 'reconcile-task':
            parser.add_argument('--event', required=True)
            parser.add_argument('--stop-observation', type=Path, help='Attributed JSON stop observation for a legacy Codex timeout; requires --retry-native')
            group = parser.add_mutually_exclusive_group(required=True)
            group.add_argument('--reply', type=Path)
            group.add_argument('--retry-read-only', action='store_true')
            group.add_argument('--retry-native', action='store_true', help='Authorize one stopped Codex build timeout retry; external effects remain unknown')
            group.add_argument('--retry-refused', action='store_true', help='Authorize one retry of a participant turn the Claude CLI refused with a structured error; usage may repeat')
            group.add_argument('--observe-file', action='store_true', help='Reconcile a replacement from observed after-bytes')
            group.add_argument('--retry-before', action='store_true', help='Authorize one replacement retry only if original bytes remain')
        elif name == 'transfer-task':
            parser.add_argument('--assessor', required=True)
            parser.add_argument('--reason', required=True)
        elif name == 'cancel-task':
            parser.add_argument('--reason', required=True)


def execute_control(args):
    from .task_policies import inspect_task, execute_task, control_task
    try:
        continuation = getattr(args, 'continuation', None)
        included = getattr(args, 'include_task', [])
        if included and getattr(args, 'format', 'json') == 'json':
            raise ValueError('--include-task requires --format markdown or html; default JSON is unchanged')
        if continuation is not None and getattr(args, 'format', 'json') == 'json':
            raise ValueError('--continuation requires --format markdown or html; default JSON is unchanged')
        readable = args.command == 'status' and getattr(args, 'format', 'json') != 'json'
        if readable and not included:
            from .review_store import read_record
            # Feature work has its own return-to-work snapshot; every other task renders its
            # status envelope below (first-run journey R5). A continuation note is feature-work only.
            feature = read_record(args.task_dir).get('task_profile') == 'feature-work-v1'
            if not feature and continuation is not None:
                raise ValueError('--continuation applies to feature-work-v1 snapshots only')
            readable = feature
        if readable:
            from .task_view import inspect, render, inspect_saved_tasks, render_saved_tasks
            if included:
                print(render_saved_tasks(inspect_saved_tasks(
                    args.task_dir, included, continuation=continuation), args.format))
            else:
                print(render(inspect(args.task_dir, continuation=continuation), args.format))
            return 0
        if (args.command == 'reconcile-task' and args.stop_observation is not None
                and not args.retry_native):
            raise ValueError('--stop-observation requires --retry-native')
        from .review_store import read_record
        if read_record(args.task_dir).get('task_profile') == 'feature-work-v1':
            from .work_cli import execute_control as execute_work_control
            return execute_work_control(args)
        if args.command == 'reconcile-task' and args.retry_native:
            raise ValueError('Native retry applies only to feature builds')
        if args.command == 'resume' and (args.allow_external or args.allow_native):
            raise ValueError('These dispatch options apply only to feature work; existing tasks retain their saved permissions')
        if args.command == 'status':
            from .review_store import read_record, inspect_run
            result = (inspect_run(args.task_dir) if read_record(args.task_dir).get('operation') == 'review'
                      else inspect_task(args.task_dir))
        elif args.command == 'resume':
            result = execute_task(args.task_dir, checkpoint=args.checkpoint, max_operations=args.max_operations)
        else:
            options = {'reconcile-task': lambda: {'event_id':args.event,'reply_file':args.reply,'retry_read_only':args.retry_read_only,'retry_refused':args.retry_refused,'observe_file':args.observe_file,'retry_before':args.retry_before},
                       'transfer-task': lambda: {'participant_id':args.assessor,'reason':args.reason},
                       'cancel-task': lambda: {'reason':args.reason}}
            result = control_task(args.task_dir, args.command.split('-')[0],
                                  checkpoint=args.checkpoint, **options[args.command]())
        if result.get('task_profile') == 'pytest-change-v1':
            from .test_change import public_test_task
            result = public_test_task(result)
        if args.command == 'status' and getattr(args, 'format', 'json') != 'json':
            from .human_output import document, markdown
            print(markdown(result) if args.format == 'markdown' else document(result), end='')
            return 0
        print(json.dumps(result, ensure_ascii=False, allow_nan=False, indent=2))
        if args.command == 'status':
            return 0
        if result.get('task_profile') == 'pytest-change-v1':
            from .test_change import exit_code
            return exit_code(result)
        return 0 if result['status'] == 'completed' else (1 if result['status'] in ('paused','cancelled') else 2)
    except Exception as exc:
        from .recovery import UnresolvedOperation
        print(json.dumps({'status':'unresolved' if isinstance(exc,UnresolvedOperation) else 'failed',
                          'error':{'type':type(exc).__name__,'detail':str(exc)},
                          'next_action': (f'Check that {args.task_dir} is a Harness task directory holding its '
                                          'record.json' if args.command == 'status' else
                                          'Inspect the task with attune-harness status before choosing an action; '
                                          'do not retry an uncertain operation blindly')}))
        return 2


def add_fix(sub):
    parser = sub.add_parser('fix', help='Repair scoped files and check the result')
    from .human_output import add_format
    add_format(parser)
    parser.add_argument('--goal')
    parser.add_argument('--project',type=Path)
    parser.add_argument('--config',type=Path)
    parser.add_argument('--checkout',type=Path,help='Dedicated POSIX checkout; task state must be outside it')
    parser.add_argument('--scope',nargs='+',help='Explicit existing relative UTF-8 replacement paths')
    parser.add_argument('--probe',type=Path,help='Trusted frozen probe JSON (argv/cwd/environment/limits/oracles)')
    parser.add_argument('--worker')
    parser.add_argument('--review',choices=('none','requested','required'),default=None)
    parser.add_argument('--reviewer')
    parser.add_argument('--criteria')
    parser.add_argument('--from-assessment',type=Path,
                        help='Completed structured assessment task supplying selected finding provenance')
    parser.add_argument('--finding-id',action='append',dest='finding_ids',
                        help='Assessment finding ID to retain; repeat for multiple findings')
    parser.add_argument('--task-dir',type=Path)
    parser.add_argument('--task-response',type=Path)
    parser.add_argument('--accept',action='store_true')
    parser.add_argument('--intake-only',action='store_true')
    parser.add_argument('--allow-external',action='store_true')
    parser.add_argument('--pause-after',type=int)
    parser.add_argument('--bypass-intake-cache',action='store_true')
    parser.add_argument('--clear-intake-cache',action='store_true')
    parser.set_defaults(allow_provider=False)


def validate_fix(args, parser):
    if args.task_response is not None:
        if args.task_dir is None or args.accept or args.allow_external or any(getattr(args,n) is not None for n in
                ('goal','project','config','checkout','scope','probe','worker','review','reviewer','criteria',
                 'from_assessment','finding_ids')):
            refuse('Fix response requires --task-dir and cannot override accepted inputs or permissions', FIX_MODES)
    else:
        if not args.goal or not args.checkout or not args.scope or not args.probe:
            refuse('Fix requires --goal, --checkout, --scope and --probe, or a bound --task-response', FIX_MODES)
        if (args.from_assessment is None) != (args.finding_ids is None):
            refuse('--from-assessment and at least one --finding-id are required together', FINDINGS)
        if args.finding_ids is not None and len(args.finding_ids) != len(set(args.finding_ids)):
            refuse('--finding-id values must be unique', FINDINGS)
        args.config=args.config or Path('participants.json')
        args.review=args.review or 'required'
